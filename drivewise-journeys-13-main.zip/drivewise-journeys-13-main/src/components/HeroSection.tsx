import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Star, Users, Shield, MapPin, Phone } from "lucide-react";
import heroBus from "@/assets/hero-bus.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBus})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 via-primary/60 to-primary/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Main Content */}
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-6">
              Jelajahi Indonesia dengan
              <span className="block text-secondary"> Bus Wisata Terbaik</span>
            </h1>
            
            <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl">
              Nikmati perjalanan yang aman, nyaman, dan berkesan bersama armada bus modern kami. 
              Destinasi impian Anda menanti!
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
              <Button variant="hero" size="lg" asChild>
                <Link to="/booking">
                  Booking Sekarang
                </Link>
              </Button>
              <Button variant="adventure" size="lg" asChild>
                <Link to="/fleet">
                  Lihat Armada
                </Link>
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-6 text-primary-foreground/80">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                <span className="text-sm font-medium">Asuransi Perjalanan</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                <span className="text-sm font-medium">10.000+ Pelanggan</span>
              </div>
              <div className="flex items-center gap-2">
                <Star className="h-5 w-5 text-secondary" />
                <span className="text-sm font-medium">Rating 4.8/5</span>
              </div>
            </div>
          </div>

          {/* Quick Booking Card */}
          <div className="flex justify-center lg:justify-end">
            <Card className="w-full max-w-md bg-card/95 backdrop-blur-sm border-border/50 shadow-card p-6">
              <h3 className="text-xl font-semibold text-card-foreground mb-4">
                Booking Cepat
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-card-foreground mb-2">
                    Tujuan Wisata
                  </label>
                  <select className="w-full p-3 border border-border rounded-lg bg-background text-foreground">
                    <option>Pilih Destinasi</option>
                    <option>Yogyakarta - Borobudur</option>
                    <option>Bali - Ubud</option>
                    <option>Bandung - Lembang</option>
                    <option>Jakarta - Puncak</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">
                      Tanggal
                    </label>
                    <input 
                      type="date" 
                      className="w-full p-3 border border-border rounded-lg bg-background text-foreground"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">
                      Penumpang
                    </label>
                    <select className="w-full p-3 border border-border rounded-lg bg-background text-foreground">
                      <option>20 Orang</option>
                      <option>35 Orang</option>
                      <option>50+ Orang</option>
                    </select>
                  </div>
                </div>

                <Button className="w-full" variant="default" size="lg" asChild>
                  <Link to="/booking">
                    <MapPin className="h-5 w-5 mr-2" />
                    Cari Bus Tersedia
                  </Link>
                </Button>

                <div className="flex items-center justify-center gap-2 text-muted-foreground">
                  <Phone className="h-4 w-4" />
                  <span className="text-sm">Atau hubungi: +62 812-3456-7890</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;