import { Link } from "react-router-dom";
import { Bus, Phone, Mail, MapPin, Facebook, Instagram, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-10 w-10">
                <img src="/src/assets/inds88-logo.png" alt="IND'S 88 TRANS" className="h-10 w-auto brightness-0 invert" />
              </div>
              <div>
                <h3 className="text-xl font-bold">IND'S 88 TRANS</h3>
                <p className="text-sm text-primary-foreground/80">Travel Indonesia</p>
              </div>
            </div>
            <p className="text-primary-foreground/80 mb-6 leading-relaxed">
              Perusahaan bus wisata terpercaya dengan lebih dari 10 tahun pengalaman. 
              Kami berkomitmen memberikan layanan perjalanan yang aman, nyaman, dan berkesan 
              ke seluruh destinasi wisata di Indonesia.
            </p>
            <div className="flex gap-3">
              <Button variant="ghost" size="icon" className="hover:bg-primary-foreground/10">
                <Facebook className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:bg-primary-foreground/10">
                <Instagram className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:bg-primary-foreground/10">
                <Twitter className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Menu Utama</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">Beranda</Link></li>
              <li><Link to="/fleet" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">Armada Bus</Link></li>
              <li><Link to="/packages" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">Paket Wisata</Link></li>
              <li><Link to="/booking" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">Booking</Link></li>
              <li><Link to="/promo" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">Promo</Link></li>
              <li><Link to="/about" className="text-primary-foreground/80 hover:text-primary-foreground transition-colors">Tentang Kami</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Kontak Kami</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Phone className="h-5 w-5 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">+62 812-3456-7890</p>
                  <p className="text-primary-foreground/80 text-sm">24 Jam Customer Service</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="h-5 w-5 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">info@inds88trans.com</p>
                  <p className="text-primary-foreground/80 text-sm">Booking & Informasi</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Jakarta, Indonesia</p>
                  <p className="text-primary-foreground/80 text-sm">Kantor Pusat</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-primary-foreground/20 mt-12 pt-8 text-center">
          <p className="text-primary-foreground/80">
            © 2024 IND'S 88 TRANS Travel Indonesia. Semua hak cipta dilindungi.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;