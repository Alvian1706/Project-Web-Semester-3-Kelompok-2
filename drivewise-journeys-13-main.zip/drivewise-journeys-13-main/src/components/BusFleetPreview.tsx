import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Users, Wifi, Wind, Zap, Star, ArrowRight } from "lucide-react";
import busFleet from "@/assets/bus-fleet.jpg";
import busInterior from "@/assets/bus-interior.jpg";

const buses = [
  {
    id: 1,
    name: "Executive Class",
    capacity: "35 Penumpang",
    image: busFleet,
    rating: 4.9,
    reviews: 125,
    price: "Rp 1.500.000",
    features: ["AC", "WiFi", "Reclining Seat", "Charging Port"],
    description: "Bus mewah dengan fasilitas lengkap untuk perjalanan jarak jauh"
  },
  {
    id: 2,
    name: "Premium Comfort",
    capacity: "25 Penumpang", 
    image: busInterior,
    rating: 4.8,
    reviews: 89,
    price: "Rp 2.200.000",
    features: ["AC", "WiFi", "Toilet", "Entertainment"],
    description: "Bus premium dengan kursi lebar dan fasilitas hiburan"
  },
  {
    id: 3,
    name: "Family Van",
    capacity: "12 Penumpang",
    image: busFleet,
    rating: 4.7,
    reviews: 67,
    price: "Rp 850.000",
    features: ["AC", "WiFi", "Family Friendly", "Storage"],
    description: "Van keluarga untuk perjalanan grup kecil yang nyaman"
  }
];

const BusFleetPreview = () => {
  return (
    <section className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Pilihan <span className="text-primary">Armada Bus</span> Terbaik
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Berbagai tipe bus sesuai kebutuhan perjalanan Anda, mulai dari keluarga hingga grup besar
          </p>
        </div>

        {/* Bus Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {buses.map((bus) => (
            <Card key={bus.id} className="group overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-border/50">
              <div className="relative overflow-hidden">
                <img 
                  src={bus.image} 
                  alt={bus.name}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 right-4">
                  <Badge variant="secondary" className="bg-primary/90 text-primary-foreground">
                    {bus.capacity}
                  </Badge>
                </div>
              </div>

              <CardHeader>
                <div className="flex justify-between items-start mb-2">
                  <CardTitle className="text-xl text-foreground">{bus.name}</CardTitle>
                  <div className="text-right">
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-secondary fill-current" />
                      <span className="text-sm font-medium text-foreground">{bus.rating}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">({bus.reviews} ulasan)</p>
                  </div>
                </div>
                
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {bus.description}
                </p>
              </CardHeader>

              <CardContent>
                <div className="flex flex-wrap gap-2 mb-4">
                  {bus.features.map((feature, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-lg font-semibold text-foreground">{bus.price}</p>
                    <p className="text-xs text-muted-foreground">per hari</p>
                  </div>
                  <Button variant="default" size="sm" asChild>
                    <Link to={`/fleet/${bus.id}`}>
                      Detail
                      <ArrowRight className="h-4 w-4 ml-1" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button variant="hero" size="lg" asChild>
            <Link to="/fleet">
              Lihat Semua Armada
              <ArrowRight className="h-5 w-5 ml-2" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default BusFleetPreview;