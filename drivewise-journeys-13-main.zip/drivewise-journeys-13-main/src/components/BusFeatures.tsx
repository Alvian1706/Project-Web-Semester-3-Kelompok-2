import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Wifi, Zap, Wind, Users, Shield, Clock } from "lucide-react";

const features = [
  {
    icon: Wind,
    title: "AC Full Blast",
    description: "Pendingin ruangan berkualitas untuk kenyamanan maksimal"
  },
  {
    icon: Wifi,
    title: "WiFi Gratis",
    description: "Koneksi internet cepat sepanjang perjalanan"
  },
  {
    icon: Zap,
    title: "Charging Port",
    description: "Colokan listrik di setiap kursi untuk gadget Anda"
  },
  {
    icon: Users,
    title: "Kursi Reclining",
    description: "Kursi yang dapat disandarkaan untuk istirahat optimal"
  },
  {
    icon: Shield,
    title: "Asuransi Perjalanan",
    description: "Perlindungan lengkap untuk keamanan perjalanan"
  },
  {
    icon: Clock,
    title: "On Time Guarantee",
    description: "Jaminan tepat waktu atau gratis perjalanan berikutnya"
  }
];

const BusFeatures = () => {
  return (
    <section className="py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Mengapa Memilih <span className="text-primary">IND'S 88 TRANS?</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Fasilitas lengkap dan pelayanan terbaik untuk perjalanan wisata yang tak terlupakan
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-border/50">
              <CardHeader className="text-center">
                <div className="w-16 h-16 mx-auto bg-gradient-to-br from-primary to-primary-glow rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="h-8 w-8 text-primary-foreground" />
                </div>
                <CardTitle className="text-xl text-foreground">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-center leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BusFeatures;