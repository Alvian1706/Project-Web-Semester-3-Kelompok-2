import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Phone, Mail, MapPin, Clock, MessageCircle, Send } from "lucide-react";

const contactMethods = [
  {
    icon: Phone,
    title: "Telepon & WhatsApp",
    details: ["+62 812-3456-7890", "+62 21-5555-7890"],
    description: "Customer service 24 jam siap membantu",
    color: "bg-primary"
  },
  {
    icon: Mail,
    title: "Email",
    details: ["info@inds88trans.com", "booking@inds88trans.com"],
    description: "Respon dalam 1x24 jam",
    color: "bg-secondary"
  },
  {
    icon: MapPin,
    title: "Kantor Pusat",
    details: ["Jl. Sudirman No. 123", "Jakarta Pusat 10220"],
    description: "Buka Senin-Sabtu 08:00-17:00",
    color: "bg-accent"
  },
  {
    icon: Clock,
    title: "Jam Operasional",
    details: ["Senin - Sabtu: 08:00 - 17:00", "Minggu: 09:00 - 15:00"],
    description: "Emergency hotline 24/7",
    color: "bg-primary"
  }
];

const offices = [
  {
    city: "Jakarta",
    address: "Jl. Sudirman No. 123, Jakarta Pusat",
    phone: "+62 21-5555-7890",
    email: "jakarta@inds88trans.com"
  },
  {
    city: "Bandung", 
    address: "Jl. Asia Afrika No. 45, Bandung",
    phone: "+62 22-4444-5678",
    email: "bandung@inds88trans.com"
  },
  {
    city: "Yogyakarta",
    address: "Jl. Malioboro No. 67, Yogyakarta", 
    phone: "+62 274-333-4567",
    email: "yogya@inds88trans.com"
  },
  {
    city: "Surabaya",
    address: "Jl. Pemuda No. 89, Surabaya",
    phone: "+62 31-2222-3456",
    email: "surabaya@inds88trans.com"
  }
];

const Contact = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-12 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Hubungi <span className="text-primary">Kami</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Tim customer service kami siap membantu merencanakan perjalanan impian Anda
            </p>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {contactMethods.map((method, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow border-border/50">
                <CardHeader>
                  <div className={`w-16 h-16 mx-auto ${method.color} rounded-xl flex items-center justify-center mb-4`}>
                    <method.icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-xl text-foreground">{method.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-1 mb-3">
                    {method.details.map((detail, idx) => (
                      <p key={idx} className="font-medium text-foreground">{detail}</p>
                    ))}
                  </div>
                  <p className="text-muted-foreground text-sm">
                    {method.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="border-border/50 shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl text-foreground flex items-center gap-2">
                  <MessageCircle className="h-6 w-6 text-primary" />
                  Kirim Pesan
                </CardTitle>
                <p className="text-muted-foreground">
                  Isi form di bawah dan kami akan menghubungi Anda segera
                </p>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nama Lengkap *</Label>
                    <Input placeholder="Nama Anda" />
                  </div>
                  <div>
                    <Label htmlFor="phone">Nomor HP *</Label>
                    <Input placeholder="08123456789" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input type="email" placeholder="email@example.com" />
                </div>

                <div>
                  <Label htmlFor="subject">Subjek</Label>
                  <Input placeholder="Tentang apa yang ingin Anda tanyakan?" />
                </div>

                <div>
                  <Label htmlFor="message">Pesan *</Label>
                  <Textarea 
                    placeholder="Jelaskan kebutuhan atau pertanyaan Anda..."
                    className="min-h-32"
                  />
                </div>

                <Button variant="hero" size="lg" className="w-full">
                  <Send className="h-5 w-5 mr-2" />
                  Kirim Pesan
                </Button>
              </CardContent>
            </Card>

            {/* Office Locations */}
            <div className="space-y-6">
              <div>
                <h3 className="text-2xl font-bold text-foreground mb-4">
                  Kantor <span className="text-primary">Cabang</span>
                </h3>
                <p className="text-muted-foreground mb-6">
                  Kunjungi kantor terdekat untuk konsultasi langsung
                </p>
              </div>

              <div className="space-y-4">
                {offices.map((office, index) => (
                  <Card key={index} className="border-border/50">
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-lg text-foreground mb-2">
                        {office.city}
                      </h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                          <span className="text-muted-foreground">{office.address}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <span className="text-foreground font-medium">{office.phone}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          <span className="text-foreground">{office.email}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Quick Actions */}
              <div className="bg-primary/5 p-6 rounded-lg border border-primary/20">
                <h4 className="font-semibold text-foreground mb-4">Butuh Respon Cepat?</h4>
                <div className="space-y-3">
                  <Button variant="hero" size="sm" className="w-full justify-start">
                    <Phone className="h-4 w-4 mr-2" />
                    Telepon Langsung: +62 812-3456-7890
                  </Button>
                  <Button variant="adventure" size="sm" className="w-full justify-start">
                    <MessageCircle className="h-4 w-4 mr-2" />
                    WhatsApp: Chat Sekarang
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-muted/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Pertanyaan yang Sering Ditanyakan
            </h3>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {[
              {
                q: "Berapa lama sebelumnya harus booking?",
                a: "Minimal 3 hari sebelum keberangkatan. Untuk peak season, disarankan 1-2 minggu sebelumnya."
              },
              {
                q: "Apakah bisa cancel atau reschedule?",
                a: "Bisa, dengan syarat pemberitahuan minimal 24 jam sebelum keberangkatan. Berlaku ketentuan cancellation fee."
              },
              {
                q: "Bagaimana sistem pembayaran?",
                a: "Tersedia DP 30% atau bayar lunas. Transfer bank, e-wallet, atau cash di kantor."
              },
              {
                q: "Apakah ada asuransi perjalanan?",
                a: "Ya, semua perjalanan sudah tercover asuransi perjalanan dari perusahaan asuransi terpercaya."
              }
            ].map((faq, index) => (
              <Card key={index} className="border-border/50">
                <CardContent className="p-4">
                  <h4 className="font-medium text-foreground mb-2">{faq.q}</h4>
                  <p className="text-muted-foreground text-sm">{faq.a}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Contact;