import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Calendar, Users, MapPin, Phone, Mail, CreditCard, Check, Bus } from "lucide-react";

const Booking = () => {
  const [step, setStep] = useState(1);
  const [bookingData, setBookingData] = useState({
    serviceType: "",
    destination: "",
    departureDate: "",
    returnDate: "",
    passengers: "",
    busType: "",
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    specialRequests: "",
    paymentMethod: "dp"
  });

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
  };

  const handlePrevious = () => {
    if (step > 1) setStep(step - 1);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-12 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Booking <span className="text-primary">Bus Wisata</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Isi form booking dengan lengkap untuk mendapatkan penawaran terbaik
            </p>
          </div>
        </div>
      </section>

      {/* Progress Steps */}
      <section className="py-8 bg-muted/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center">
            <div className="flex items-center space-x-4">
              {[1, 2, 3].map((stepNumber) => (
                <div key={stepNumber} className="flex items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-medium ${
                    step >= stepNumber 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted text-muted-foreground"
                  }`}>
                    {step > stepNumber ? <Check className="h-5 w-5" /> : stepNumber}
                  </div>
                  <div className="ml-2 text-sm font-medium text-foreground">
                    {stepNumber === 1 && "Detail Perjalanan"}
                    {stepNumber === 2 && "Data Pemesan"}
                    {stepNumber === 3 && "Konfirmasi"}
                  </div>
                  {stepNumber < 3 && <div className="w-8 h-px bg-border ml-4" />}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Booking Form */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-border/50 shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-foreground flex items-center gap-2">
                <Bus className="h-6 w-6 text-primary" />
                {step === 1 && "Detail Perjalanan"}
                {step === 2 && "Data Pemesan"}
                {step === 3 && "Konfirmasi Booking"}
              </CardTitle>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Step 1: Trip Details */}
              {step === 1 && (
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="serviceType">Jenis Layanan *</Label>
                      <Select value={bookingData.serviceType} onValueChange={(value) => 
                        setBookingData({...bookingData, serviceType: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih jenis layanan" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sewa-harian">Sewa Bus Harian</SelectItem>
                          <SelectItem value="paket-wisata">Paket Wisata</SelectItem>
                          <SelectItem value="antar-jemput">Antar Jemput</SelectItem>
                          <SelectItem value="custom">Custom Trip</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="destination">Tujuan / Destinasi *</Label>
                      <Input 
                        placeholder="Contoh: Yogyakarta, Bali, Bandung"
                        value={bookingData.destination}
                        onChange={(e) => setBookingData({...bookingData, destination: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="departureDate">Tanggal Keberangkatan *</Label>
                      <Input 
                        type="date"
                        value={bookingData.departureDate}
                        onChange={(e) => setBookingData({...bookingData, departureDate: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="returnDate">Tanggal Kepulangan</Label>
                      <Input 
                        type="date"
                        value={bookingData.returnDate}
                        onChange={(e) => setBookingData({...bookingData, returnDate: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="passengers">Jumlah Penumpang *</Label>
                      <Input 
                        type="number"
                        placeholder="Contoh: 25"
                        value={bookingData.passengers}
                        onChange={(e) => setBookingData({...bookingData, passengers: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="busType">Tipe Bus</Label>
                      <Select value={bookingData.busType} onValueChange={(value) => 
                        setBookingData({...bookingData, busType: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih tipe bus" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="executive">Executive Class (35 kursi)</SelectItem>
                          <SelectItem value="premium">Premium Comfort (25 kursi)</SelectItem>
                          <SelectItem value="luxury">Luxury Coach (45 kursi)</SelectItem>
                          <SelectItem value="minibus">Mini Bus (15 kursi)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="specialRequests">Permintaan Khusus</Label>
                    <Textarea 
                      placeholder="Contoh: Perlu tour guide, makanan halal, wheelchair accessible..."
                      value={bookingData.specialRequests}
                      onChange={(e) => setBookingData({...bookingData, specialRequests: e.target.value})}
                      className="min-h-20"
                    />
                  </div>
                </div>
              )}

              {/* Step 2: Customer Data */}
              {step === 2 && (
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="customerName">Nama Lengkap *</Label>
                      <Input 
                        placeholder="Nama sesuai KTP"
                        value={bookingData.customerName}
                        onChange={(e) => setBookingData({...bookingData, customerName: e.target.value})}
                      />
                    </div>

                    <div>
                      <Label htmlFor="customerPhone">Nomor HP *</Label>
                      <Input 
                        placeholder="Contoh: 08123456789"
                        value={bookingData.customerPhone}
                        onChange={(e) => setBookingData({...bookingData, customerPhone: e.target.value})}
                      />
                    </div>

                    <div className="md:col-span-2">
                      <Label htmlFor="customerEmail">Email *</Label>
                      <Input 
                        type="email"
                        placeholder="email@example.com"
                        value={bookingData.customerEmail}
                        onChange={(e) => setBookingData({...bookingData, customerEmail: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Label className="text-base font-medium">Metode Pembayaran</Label>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="dp"
                          checked={bookingData.paymentMethod === "dp"}
                          onCheckedChange={(checked) => {
                            if (checked) setBookingData({...bookingData, paymentMethod: "dp"});
                          }}
                        />
                        <Label htmlFor="dp" className="text-sm">
                          DP 30% (Sisanya H-3 sebelum keberangkatan)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="full"
                          checked={bookingData.paymentMethod === "full"}
                          onCheckedChange={(checked) => {
                            if (checked) setBookingData({...bookingData, paymentMethod: "full"});
                          }}
                        />
                        <Label htmlFor="full" className="text-sm">
                          Bayar Lunas (Dapatkan diskon 5%)
                        </Label>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Confirmation */}
              {step === 3 && (
                <div className="space-y-6">
                  <div className="bg-muted/30 p-6 rounded-lg">
                    <h3 className="font-semibold text-lg text-foreground mb-4">Ringkasan Booking</h3>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Jenis Layanan:</p>
                        <p className="font-medium">{bookingData.serviceType || "-"}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Destinasi:</p>
                        <p className="font-medium">{bookingData.destination || "-"}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Tanggal:</p>
                        <p className="font-medium">{bookingData.departureDate || "-"}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Penumpang:</p>
                        <p className="font-medium">{bookingData.passengers ? `${bookingData.passengers} orang` : "-"}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Nama Pemesan:</p>
                        <p className="font-medium">{bookingData.customerName || "-"}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Kontak:</p>
                        <p className="font-medium">{bookingData.customerPhone || "-"}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-primary/5 p-6 rounded-lg border border-primary/20">
                    <h4 className="font-medium text-foreground mb-2">Langkah Selanjutnya:</h4>
                    <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
                      <li>Tim kami akan menghubungi Anda dalam 1x24 jam</li>
                      <li>Konfirmasi detail perjalanan dan harga final</li>
                      <li>Pembayaran sesuai metode yang dipilih</li>
                      <li>Receive e-ticket dan detail perjalanan</li>
                    </ol>
                  </div>
                </div>
              )}

              {/* Navigation Buttons */}
              <div className="flex justify-between pt-6 border-t border-border">
                <Button 
                  variant="outline" 
                  onClick={handlePrevious}
                  disabled={step === 1}
                >
                  Sebelumnya
                </Button>
                
                {step < 3 ? (
                  <Button 
                    variant="hero"
                    onClick={handleNext}
                  >
                    Selanjutnya
                  </Button>
                ) : (
                  <Button variant="hero" size="lg">
                    <CreditCard className="h-5 w-5 mr-2" />
                    Submit Booking
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Booking;