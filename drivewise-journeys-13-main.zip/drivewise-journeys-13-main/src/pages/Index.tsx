import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import BusFeatures from "@/components/BusFeatures";
import BusFleetPreview from "@/components/BusFleetPreview";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <HeroSection />
        <BusFeatures />
        <BusFleetPreview />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
