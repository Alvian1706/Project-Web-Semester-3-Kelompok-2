import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Link } from "react-router-dom";
import { Users, Wifi, Wind, Zap, Star, Search, Filter, ArrowRight, Phone } from "lucide-react";
import busFleet from "@/assets/bus-fleet.jpg";
import busInterior from "@/assets/bus-interior.jpg";

const allBuses = [
  {
    id: 1,
    name: "Executive Class",
    capacity: "35 Penumpang",
    image: busFleet,
    rating: 4.9,
    reviews: 125,
    price: "Rp 1.500.000",
    features: ["AC", "WiFi", "Reclining Seat", "Charging Port"],
    description: "Bus mewah dengan fasilitas lengkap untuk perjalanan jarak jauh",
    category: "large"
  },
  {
    id: 2,
    name: "Premium Comfort",
    capacity: "25 Penumpang", 
    image: busInterior,
    rating: 4.8,
    reviews: 89,
    price: "Rp 2.200.000",
    features: ["AC", "WiFi", "Toilet", "Entertainment"],
    description: "Bus premium dengan kursi lebar dan fasilitas hiburan",
    category: "medium"
  },
  {
    id: 3,
    name: "Family Van",
    capacity: "12 Penumpang",
    image: busFleet,
    rating: 4.7,
    reviews: 67,
    price: "Rp 850.000",
    features: ["AC", "WiFi", "Family Friendly", "Storage"],
    description: "Van keluarga untuk perjalanan grup kecil yang nyaman",
    category: "small"
  },
  {
    id: 4,
    name: "Luxury Coach",
    capacity: "45 Penumpang",
    image: busInterior,
    rating: 4.9,
    reviews: 203,
    price: "Rp 2.800.000",
    features: ["AC", "WiFi", "Toilet", "Reclining Seat", "Entertainment", "Meal Service"],
    description: "Bus mewah terbesar dengan layanan premium dan fasilitas terlengkap",
    category: "large"
  },
  {
    id: 5,
    name: "City Explorer",
    capacity: "20 Penumpang",
    image: busFleet,
    rating: 4.6,
    reviews: 95,
    price: "Rp 1.200.000",
    features: ["AC", "WiFi", "Panoramic Windows", "Storage"],
    description: "Bus ideal untuk city tour dengan jendela panorama",
    category: "medium"
  },
  {
    id: 6,
    name: "Mini Bus Deluxe",
    capacity: "15 Penumpang",
    image: busInterior,
    rating: 4.8,
    reviews: 78,
    price: "Rp 950.000",
    features: ["AC", "WiFi", "Comfortable Seats", "Charging Port"],
    description: "Mini bus nyaman untuk grup sedang dengan fasilitas modern",
    category: "small"
  }
];

const Fleet = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sortBy, setSortBy] = useState("rating");

  const filteredBuses = allBuses
    .filter(bus => 
      bus.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (categoryFilter === "all" || bus.category === categoryFilter)
    )
    .sort((a, b) => {
      if (sortBy === "rating") return b.rating - a.rating;
      if (sortBy === "price") return parseInt(a.price.replace(/\D/g, '')) - parseInt(b.price.replace(/\D/g, ''));
      return 0;
    });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-12 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Armada <span className="text-primary">Bus Wisata</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Pilih bus yang tepat untuk perjalanan wisata Anda. Semua armada dalam kondisi prima dan terawat
            </p>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-muted/20 border-y border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input 
                placeholder="Cari nama bus atau fasilitas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <div className="flex gap-4 items-center">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Semua Tipe</SelectItem>
                    <SelectItem value="small">Kecil (≤15)</SelectItem>
                    <SelectItem value="medium">Sedang (16-30)</SelectItem>
                    <SelectItem value="large">Besar (≥31)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rating">Rating Tertinggi</SelectItem>
                  <SelectItem value="price">Harga Terendah</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Bus Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredBuses.map((bus) => (
              <Card key={bus.id} className="group overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-border/50">
                <div className="relative overflow-hidden">
                  <img 
                    src={bus.image} 
                    alt={bus.name}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4">
                    <Badge variant="secondary" className="bg-primary/90 text-primary-foreground">
                      {bus.capacity}
                    </Badge>
                  </div>
                </div>

                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl text-foreground">{bus.name}</CardTitle>
                    <div className="text-right">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-secondary fill-current" />
                        <span className="text-sm font-medium text-foreground">{bus.rating}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">({bus.reviews} ulasan)</p>
                    </div>
                  </div>
                  
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {bus.description}
                  </p>
                </CardHeader>

                <CardContent>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {bus.features.map((feature, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-lg font-semibold text-foreground">{bus.price}</p>
                      <p className="text-xs text-muted-foreground">per hari</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" size="sm" asChild>
                      <Link to={`/fleet/${bus.id}`}>
                        Detail
                      </Link>
                    </Button>
                    <Button variant="hero" size="sm" asChild>
                      <Link to={`/booking?bus=${bus.id}`}>
                        Booking
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredBuses.length === 0 && (
            <div className="text-center py-16">
              <p className="text-muted-foreground text-lg mb-4">
                Tidak ada bus yang sesuai dengan kriteria pencarian
              </p>
              <Button variant="outline" onClick={() => {
                setSearchTerm("");
                setCategoryFilter("all");
              }}>
                Reset Filter
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary/5 to-secondary/5">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
            Butuh Bantuan Memilih Bus?
          </h3>
          <p className="text-lg text-muted-foreground mb-8">
            Tim kami siap membantu Anda menemukan bus yang tepat sesuai kebutuhan perjalanan
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="hero" size="lg" asChild>
              <Link to="/contact">
                <Phone className="h-5 w-5 mr-2" />
                Hubungi Kami
              </Link>
            </Button>
            <Button variant="adventure" size="lg" asChild>
              <Link to="/booking">
                Mulai Booking
                <ArrowRight className="h-5 w-5 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Fleet;