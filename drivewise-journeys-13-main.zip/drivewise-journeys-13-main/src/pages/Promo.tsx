import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Link } from "react-router-dom";
import { Tag, Calendar, Users, Gift, Percent, Clock, ArrowRight, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const promos = [
  {
    id: 1,
    title: "Early Bird 2024",
    description: "Booking 1 bulan sebelumnya dapatkan diskon hingga 25%",
    discount: "25%",
    code: "EARLY2024",
    validUntil: "31 Desember 2024",
    minOrder: "Rp 2.000.000",
    terms: [
      "Berlaku untuk semua paket wisata",
      "Booking minimal 30 hari sebelum keberangkatan", 
      "Tidak dapat digabung dengan promo lain",
      "Berlaku untuk grup minimal 20 orang"
    ],
    type: "percentage",
    color: "bg-primary"
  },
  {
    id: 2,
    title: "Weekend Special",
    description: "Khusus weekend, gratis 1 orang untuk setiap 10 peserta",
    discount: "1 GRATIS",
    code: "WEEKEND10",
    validUntil: "Setiap Sabtu-Minggu",
    minOrder: "Minimal 10 orang",
    terms: [
      "Berlaku untuk trip weekend (Sabtu-Minggu)",
      "Gratis 1 orang setiap kelipatan 10 peserta",
      "Tidak berlaku pada hari libur nasional",
      "Maksimal 5 orang gratis per grup"
    ],
    type: "bonus",
    color: "bg-secondary"
  },
  {
    id: 3,
    title: "Student Discount",
    description: "Diskon khusus pelajar dan mahasiswa dengan kartu identitas",
    discount: "15%",
    code: "STUDENT15",
    validUntil: "Setiap hari",
    minOrder: "Minimal 15 orang",
    terms: [
      "Wajib menunjukkan kartu pelajar/mahasiswa",
      "Berlaku untuk semua destinasi",
      "Minimal 15 peserta pelajar",
      "Tidak berlaku pada peak season"
    ],
    type: "percentage", 
    color: "bg-accent"
  },
  {
    id: 4,
    title: "Corporate Package",
    description: "Paket khusus perusahaan dengan fasilitas meeting on the bus",
    discount: "20%",
    code: "CORPORATE20",
    validUntil: "31 Maret 2025",
    minOrder: "Minimal 25 orang",
    terms: [
      "Khusus untuk company outing/gathering",
      "Include meeting kit & sound system",
      "Free dokumentasi foto & video",
      "Catering box dapat disesuaikan"
    ],
    type: "package",
    color: "bg-primary"
  },
  {
    id: 5,
    title: "Ramadan Special",
    description: "Paket wisata religi dengan jadwal shalat dan makanan halal",
    discount: "30%",
    code: "RAMADAN30", 
    validUntil: "30 April 2024",
    minOrder: "Minimal 20 orang",
    terms: [
      "Berlaku untuk wisata religi",
      "Include jadwal shalat & mushola terdekat",
      "Makanan dijamin halal MUI",
      "Panduan ibadah selama perjalanan"
    ],
    type: "special",
    color: "bg-accent"
  },
  {
    id: 6,
    title: "Family Trip Bonanza", 
    description: "Anak di bawah 5 tahun gratis, usia 5-12 tahun setengah harga",
    discount: "50%",
    code: "FAMILY50",
    validUntil: "Setiap hari",
    minOrder: "Minimal 3 keluarga",
    terms: [
      "Anak <5 tahun tidak bayar (tidak dapat seat)",
      "Anak 5-12 tahun bayar 50%",
      "Minimal booking 3 keluarga",
      "Berlaku untuk semua destinasi family-friendly"
    ],
    type: "family",
    color: "bg-secondary"
  }
];

const Promo = () => {
  const { toast } = useToast();

  const copyPromoCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({
      title: "Kode promo disalin!",
      description: `Kode ${code} telah disalin ke clipboard`,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-12 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Promo <span className="text-primary">Menarik</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Dapatkan penawaran terbaik untuk perjalanan wisata impian Anda
            </p>
          </div>
        </div>
      </section>

      {/* Promo Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {promos.map((promo) => (
              <Card key={promo.id} className="group relative overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-border/50">
                {/* Discount Badge */}
                <div className={`absolute top-4 right-4 ${promo.color} text-white px-3 py-1 rounded-full text-sm font-bold z-10`}>
                  {promo.type === 'percentage' && <Percent className="inline h-4 w-4 mr-1" />}
                  {promo.type === 'bonus' && <Gift className="inline h-4 w-4 mr-1" />}
                  {promo.type === 'package' && <Users className="inline h-4 w-4 mr-1" />}
                  {promo.type === 'special' && <Tag className="inline h-4 w-4 mr-1" />}
                  {promo.type === 'family' && <Users className="inline h-4 w-4 mr-1" />}
                  {promo.discount}
                </div>

                <CardHeader className="pb-4">
                  <CardTitle className="text-xl text-foreground">{promo.title}</CardTitle>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {promo.description}
                  </p>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Promo Code */}
                  <div className="bg-muted/30 p-3 rounded-lg border border-dashed border-primary/30">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-muted-foreground">Kode Promo</p>
                        <p className="font-mono font-bold text-primary text-lg">{promo.code}</p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyPromoCode(promo.code)}
                        className="h-8 w-8 p-0"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Validity & Min Order */}
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-muted-foreground">Berlaku hingga</p>
                        <p className="font-medium text-foreground">{promo.validUntil}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="text-muted-foreground">Min. Order</p>
                        <p className="font-medium text-foreground">{promo.minOrder}</p>
                      </div>
                    </div>
                  </div>

                  {/* Terms */}
                  <div>
                    <h4 className="font-medium text-foreground mb-2 text-sm">Syarat & Ketentuan:</h4>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      {promo.terms.slice(0, 2).map((term, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="text-primary mt-1">•</span>
                          <span>{term}</span>
                        </li>
                      ))}
                      {promo.terms.length > 2 && (
                        <li className="text-primary text-xs font-medium">
                          +{promo.terms.length - 2} syarat lainnya
                        </li>
                      )}
                    </ul>
                  </div>

                  {/* CTA */}
                  <div className="pt-4 border-t border-border">
                    <Button variant="hero" size="sm" className="w-full" asChild>
                      <Link to={`/booking?promo=${promo.code}`}>
                        Gunakan Promo
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-gradient-to-r from-primary/5 to-secondary/5">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
            Jangan Lewatkan Promo Menarik Lainnya!
          </h3>
          <p className="text-lg text-muted-foreground mb-8">
            Daftarkan email Anda untuk mendapatkan update promo terbaru dan penawaran ekslusif
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input 
              type="email" 
              placeholder="Masukkan email Anda"
              className="flex-1 px-4 py-3 rounded-lg border border-border bg-background text-foreground"
            />
            <Button variant="hero" size="lg">
              Subscribe
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Promo;