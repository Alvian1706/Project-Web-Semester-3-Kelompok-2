import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Link } from "react-router-dom";
import { MapPin, Clock, Users, Star, Camera, Utensils, Bed, ArrowRight } from "lucide-react";
import destinations from "@/assets/destinations.jpg";

const packages = [
  {
    id: 1,
    name: "Yogyakarta Heritage 3D2N",
    destination: "Yogyakarta",
    duration: "3 Hari 2 Malam",
    participants: "25-35 Orang",
    price: "Rp 1.250.000",
    originalPrice: "Rp 1.450.000",
    rating: 4.8,
    reviews: 156,
    image: destinations,
    highlights: ["Borobudur", "Malioboro", "Kraton", "Prambanan"],
    includes: ["Transport AC", "Hotel 3*", "Makan 6x", "Tiket Wisata", "Tour Guide"],
    itinerary: [
      "Day 1: Tiba di Yogya - Malioboro - Kraton",
      "Day 2: Borobudur - Prambanan - Batik Center", 
      "Day 3: Taman Sari - Gudeg Yu Djum - Pulang"
    ]
  },
  {
    id: 2,
    name: "Bali Exotic 4D3N",
    destination: "Bali",
    duration: "4 Hari 3 Malam",
    participants: "20-30 Orang",
    price: "Rp 2.850.000",
    originalPrice: "Rp 3.200.000",
    rating: 4.9,
    reviews: 243,
    image: destinations,
    highlights: ["Tanah Lot", "Ubud", "Kintamani", "Bedugul"],
    includes: ["Transport AC", "Hotel 4*", "Makan 9x", "Tiket Wisata", "Tour Guide", "Asuransi"],
    itinerary: [
      "Day 1: Tiba Denpasar - Tanah Lot - Hotel",
      "Day 2: Kintamani - Ubud - Monkey Forest",
      "Day 3: Bedugul - Jatiluwih - Taman Ayun",
      "Day 4: Pantai Sanur - Oleh-oleh - Pulang"
    ]
  },
  {
    id: 3,
    name: "Bandung Cool 2D1N",
    destination: "Bandung",
    duration: "2 Hari 1 Malam", 
    participants: "30-45 Orang",
    price: "Rp 650.000",
    originalPrice: "Rp 750.000",
    rating: 4.7,
    reviews: 89,
    image: destinations,
    highlights: ["Lembang", "Tangkuban Perahu", "Kawah Putih", "Factory Outlet"],
    includes: ["Transport AC", "Hotel 3*", "Makan 4x", "Tiket Wisata", "Tour Guide"],
    itinerary: [
      "Day 1: Berangkat - Lembang - Tangkuban Perahu - Hotel",
      "Day 2: Kawah Putih - Factory Outlet - Pulang"
    ]
  },
  {
    id: 4,
    name: "Jakarta Puncak Weekend",
    destination: "Puncak Bogor",
    duration: "2 Hari 1 Malam",
    participants: "35-50 Orang", 
    price: "Rp 450.000",
    originalPrice: "Rp 550.000",
    rating: 4.6,
    reviews: 134,
    image: destinations,
    highlights: ["Kebun Teh", "Taman Safari", "Villa Khas", "Kuliner Sunda"],
    includes: ["Transport AC", "Villa", "Makan 4x", "Tiket Wisata", "BBQ Kit"],
    itinerary: [
      "Day 1: Jakarta - Kebun Teh - Villa - BBQ",
      "Day 2: Taman Safari - Kuliner - Pulang"
    ]
  }
];

const Packages = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-12 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Paket <span className="text-primary">Wisata Indonesia</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Jelajahi keindahan Indonesia dengan paket wisata lengkap. 
              Transport, hotel, makan, dan tour guide sudah termasuk!
            </p>
          </div>
        </div>
      </section>

      {/* Packages Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            {packages.map((pkg) => (
              <Card key={pkg.id} className="group overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-border/50">
                <div className="relative overflow-hidden">
                  <img 
                    src={pkg.image} 
                    alt={pkg.name}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge variant="secondary" className="bg-primary/90 text-primary-foreground">
                      {pkg.duration}
                    </Badge>
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge variant="outline" className="bg-background/90">
                      {pkg.participants}
                    </Badge>
                  </div>
                </div>

                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-xl text-foreground">{pkg.name}</CardTitle>
                    <div className="text-right">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-primary fill-current" />
                        <span className="text-sm font-medium text-foreground">{pkg.rating}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">({pkg.reviews} ulasan)</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span className="text-sm">{pkg.destination}</span>
                    <Clock className="h-4 w-4 ml-2" />
                    <span className="text-sm">{pkg.duration}</span>
                  </div>
                </CardHeader>

                <CardContent>
                  <div className="space-y-4">
                    {/* Highlights */}
                    <div>
                      <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                        <Camera className="h-4 w-4" />
                        Destinasi Utama
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {pkg.highlights.map((highlight, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {highlight}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Includes */}
                    <div>
                      <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                        <Utensils className="h-4 w-4" />
                        Termasuk
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {pkg.includes.slice(0, 3).map((item, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {item}
                          </Badge>
                        ))}
                        {pkg.includes.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{pkg.includes.length - 3} lainnya
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Pricing & CTA */}
                    <div className="flex items-center justify-between pt-4 border-t border-border">
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-lg font-bold text-foreground">{pkg.price}</p>
                          <p className="text-sm text-muted-foreground line-through">{pkg.originalPrice}</p>
                        </div>
                        <p className="text-xs text-muted-foreground">per orang</p>
                      </div>
                      <Button variant="hero" size="sm" asChild>
                        <Link to={`/booking?package=${pkg.id}`}>
                          Booking Sekarang
                          <ArrowRight className="h-4 w-4 ml-1" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary/5 to-secondary/5">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
            Paket Custom Sesuai Keinginan?
          </h3>
          <p className="text-lg text-muted-foreground mb-8">
            Kami bisa buatkan paket wisata sesuai budget dan destinasi impian Anda
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="hero" size="lg" asChild>
              <Link to="/contact">
                Konsultasi Gratis
              </Link>
            </Button>
            <Button variant="adventure" size="lg" asChild>
              <Link to="/fleet">
                Lihat Armada Bus
                <ArrowRight className="h-5 w-5 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Packages;