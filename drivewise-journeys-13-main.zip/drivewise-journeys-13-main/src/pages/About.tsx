import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Link } from "react-router-dom";
import { Shield, Award, Users, MapPin, Phone, Clock, Target, Heart, Star, CheckCircle } from "lucide-react";
import busFleet from "@/assets/bus-fleet.jpg";
import busInterior from "@/assets/bus-interior.jpg";

const stats = [
  { icon: Users, number: "10,000+", label: "Pelanggan Puas" },
  { icon: MapPin, number: "50+", label: "Destinasi Wisata" },
  { icon: Shield, number: "12", label: "Tahun Pengalaman" },
  { icon: Award, number: "98%", label: "Rating Kepuasan" }
];

const values = [
  {
    icon: Shield,
    title: "Keamanan Terjamin",
    description: "Semua bus dilengkapi asuransi perjalanan dan driver berpengalaman dengan sertifikat resmi"
  },
  {
    icon: Heart,
    title: "Pelayanan Terbaik", 
    description: "Customer service 24 jam siap membantu dan memastikan perjalanan Anda berjalan lancar"
  },
  {
    icon: Star,
    title: "Kualitas Prima",
    description: "Armada bus terawat dengan fasilitas modern untuk kenyamanan maksimal perjalanan"
  },
  {
    icon: Target,
    title: "Tepat Waktu",
    description: "Komitmen punctuality dengan jaminan tepat waktu atau gratis perjalanan berikutnya"
  }
];

const achievements = [
  "Penghargaan 'Best Travel Service' 2023",
  "Sertifikat ISO 9001:2015 untuk Quality Management",
  "Member resmi ASITA (Association of Indonesian Tours & Travel)",
  "Rating 4.8/5 dari 10.000+ ulasan pelanggan",
  "Zero accident record dalam 5 tahun terakhir",
  "Partnership dengan 200+ hotel dan destinasi wisata"
];

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-r from-primary/10 via-primary/5 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Tentang <span className="text-primary">IND'S 88 TRANS</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Perusahaan bus wisata terpercaya dengan pengalaman lebih dari 12 tahun 
              melayani perjalanan wisata ke seluruh Indonesia
            </p>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center border-border/50">
                <CardContent className="pt-6">
                  <div className="w-16 h-16 mx-auto bg-gradient-to-br from-primary to-primary-glow rounded-xl flex items-center justify-center mb-4">
                    <stat.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <h3 className="text-3xl font-bold text-foreground mb-2">{stat.number}</h3>
                  <p className="text-muted-foreground">{stat.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
                Perjalanan Dimulai dari <span className="text-primary">Mimpi</span>
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  IND'S 88 TRANS didirikan pada tahun 2012 dengan visi sederhana namun mulia: 
                  "Menghubungkan setiap orang dengan keindahan Indonesia melalui perjalanan yang aman dan berkesan."
                </p>
                <p>
                  Dimulai dari 2 unit bus dan tim kecil yang penuh semangat, kini kami telah berkembang 
                  menjadi perusahaan bus wisata terdepan dengan armada modern dan jaringan destinasi 
                  yang luas di seluruh nusantara.
                </p>
                <p>
                  Setiap perjalanan bukan hanya sekedar berpindah tempat, tetapi menciptakan 
                  pengalaman dan kenangan indah yang akan diingat selamanya. Itulah yang 
                  membuat kami terus berinovasi dan memberikan yang terbaik.
                </p>
              </div>
            </div>
            <div className="relative">
              <img 
                src={busFleet} 
                alt="IND'S 88 TRANS Fleet"
                className="rounded-xl shadow-lg"
              />
              <div className="absolute -bottom-4 -left-4 bg-primary text-primary-foreground p-4 rounded-lg shadow-lg">
                <p className="text-sm font-medium">Sejak 2012</p>
                <p className="text-2xl font-bold">12+ Tahun</p>
                <p className="text-xs">Pengalaman Terpercaya</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-muted/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Nilai-nilai <span className="text-primary">Kami</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Komitmen kami terhadap excellence dalam setiap aspek pelayanan
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow border-border/50">
                <CardHeader>
                  <div className="w-16 h-16 mx-auto bg-gradient-to-br from-primary to-primary-glow rounded-xl flex items-center justify-center mb-4">
                    <value.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-xl text-foreground">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {value.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Fleet & Facilities */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img 
                src={busInterior} 
                alt="Bus Interior"
                className="rounded-xl shadow-lg"
              />
            </div>
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
                Armada <span className="text-primary">Modern</span> & Terawat
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Seluruh armada kami menggunakan teknologi terkini dan dirawat secara berkala 
                untuk memastikan keamanan dan kenyamanan perjalanan Anda.
              </p>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-primary" />
                  <span className="text-foreground">AC full blast dengan filter udara bersih</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-primary" />
                  <span className="text-foreground">Kursi reclining dengan bantal & selimut</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-primary" />
                  <span className="text-foreground">WiFi gratis & charging port di setiap kursi</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-primary" />
                  <span className="text-foreground">Entertainment system & sound system premium</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-primary" />
                  <span className="text-foreground">Toilet bersih & air mineral gratis</span>
                </div>
              </div>

              <div className="mt-8">
                <Button variant="hero" size="lg" asChild>
                  <Link to="/fleet">
                    Lihat Armada Lengkap
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-16 bg-gradient-to-r from-primary/5 to-secondary/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Pencapaian & <span className="text-primary">Pengakuan</span>
            </h2>
            <p className="text-xl text-muted-foreground">
              Hasil dari dedikasi dan komitmen terhadap pelayanan terbaik
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {achievements.map((achievement, index) => (
              <div key={index} className="flex items-center gap-3 bg-background p-4 rounded-lg shadow-sm border border-border/50">
                <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0"></div>
                <span className="text-foreground">{achievement}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
            Siap Memulai Perjalanan Bersama Kami?
          </h3>
          <p className="text-lg text-muted-foreground mb-8">
            Tim customer service kami siap membantu merencanakan perjalanan impian Anda
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="hero" size="lg" asChild>
              <Link to="/booking">
                <Phone className="h-5 w-5 mr-2" />
                Mulai Booking
              </Link>
            </Button>
            <Button variant="adventure" size="lg" asChild>
              <Link to="/contact">
                Hubungi Kami
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;